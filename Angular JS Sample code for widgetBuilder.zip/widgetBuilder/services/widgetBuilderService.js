smartsenseApp.factory('widgetBuilderService', widgetBuilderService);

widgetBuilderService.$inject = ['grainService'];

function widgetBuilderService(grainService) {

    var sizes = {
        'full' :{
            'label':'Large - Full Width',
            'value':'col-lg-12 col-md-12 col-sm-12 col-xs-12'
        },
        'half' :{
            'label':'Medium - Half Width',
            'value':'col-lg-6 col-md-6 col-sm-12 col-xs-12'
        },
        'medium' : {
            'label':'Medium - 1/3th Width',
            'value':'col-lg-4 col-md-4 col-sm-12 col-xs-12'
        },
        'small' :{
            'label':'Small - 1/4th Width',
            'value':'col-lg-3 col-md-3 col-sm-4 col-xs-12'
        },
        'xsmall': {
            'label':'Extra Small - 1/6th Width',
            'value':'col-lg-2 col-md-3 col-sm-4 col-xs-12'
        }
    }

    var sensortypeids = [
    {id: null, label: "All"},
    {id: "1001", label: "Consumption"},
    {id: "1002,1003", label: "Generation"},
    {id: "1004", label: "Appliance Only"}
    ];

    var grains = grainService.gets();

    var frequencies = [{
        id: 'DAILY', label: 'Day', unit:'Day'
    },{
        id: 'WEEKLY', label: 'Week', unit:'Week'
    },{
        id: 'MONTHLY', label: 'Month', unit:'Month'
    }];

    var currencies = [{
        label: "Indian Rupees",
        symbol:"₹"
    },{
        label: "United Arab Emirates Dirham",
        symbol:"AED"
    }];

    var meta = {
        name:'',
        description:'',
        refreshtime:5
    }

    var operandtypes = [{
        label:'Parameter',
        value:'parameter'
    },{
        label:'Constant Value',
        value:'value'
    },{
        label:'Formula',
        value:'formula'
    }];

    var operators = [{
        label:'Add',
        value:'+',
        type:'Mathematical'
    },{
        label:'Substract',
        value:'-',
        type:'Mathematical'
    },{
        label:'Multiply',
        value:'*',
        type:'Mathematical'
    },{
        label:'Power',
        value:'**',
        type:'Mathematical'
    },{
        label:'Divide',
        value:'/',
        type:'Mathematical'
    },{
        label:'And',
        value:'and',
        type:'Logical'
    },{
        label:'Or',
        value:'or',
        type:'Logical'
    },{
        label:'>',
        value:'>',
        type:'Logical'
    },{
        label:'<',
        value:'<',
        type:'Logical'
    },{
        label:'==',
        value:'==',
        type:'Logical'
    },{
        label:'!=',
        value:'!=',
        type:'Logical'
    }];

    var chartTypes = [{
        label:'Bar Graph',
        value:'column'
    },{
        label:'Line Graph',
        value:'line'
    },{
        label:'Area Graph',
        value:'area'
    }];

    var assetTypes = [{
        label:'Motor Insight',
        value:'motor'
    },{
        label:'Transformer Insight',
        value:'transformer'
    },{
        label:'Chiller Insight',
        value:'chiller'
    }];

    var dialTypes = [{
        label:'Solid Gauge',
        value:'solidgauge'
    }, {
        label:'Speedometer',
        value:'gauge'
    }];

    var fontweights = [{
        label:'100',
        value:'100'
    }, {
        label:'200',
        value:'200'
    }, {
        label:'300',
        value:'300'
    }, {
        label:'400',
        value:'400'
    }, {
        label:'500',
        value:'500'
    }, {
        label:'600',
        value:'600'
    }, {
        label:'700',
        value:'700'
    }, {
        label:'800',
        value:'800'
    }, {
        label:'900',
        value:'900'
    }];

    var default_readingtypeid = 2001;
    var default_load_readingtypeid = 2002;

    var service = {
        operandtypes:operandtypes,
        operators:operators,
        chartTypes:chartTypes,
        // Initialization
        getObject:getObject,
        getSettings:getSettings,
    };

    return service;

    ////////////

    function Table() {
        this.config = {
            cells:[{
                alias:'',
                is_computed:false,
                parameter:{
                    readingtypeid:null,
                    locationid:null,
                    sensortypeid:null
                },
                computed_parameter:{
                    formula:[{
                        type:'parameter',
                        parameter:{}
                    }],
                    parameters:{}
                },
                col:null,
                row:null
            }],
            rows:[{
                label:'Raw 1'
            }],
            cols:[{
                label:'Column 1'
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            type:'table',
            order:0,
            class:sizes['full'].value
        };
        this.order=0;
        this.status='draft';
        this.type='table';
    }

    function TableSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 20;
        this.sizes = sizes;
    }

    function Digit() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            type:'digit',
            order:0,
            class:sizes['small'].value
        };
        this.order=0;
        this.status='draft';
        this.type='digit';
    }


    function DigitSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.sizes = [sizes['small'],sizes['xsmall']];
        this.parameterLimit = 3;
    }


    function Digit2() {
        this.config = {
            parameters:{
                'value':{
                    alias:'',
                    readingtypeid:default_readingtypeid,
                    locationid:null,
                    sensortypeid:null
                },
                'live':{
                    alias:'',
                    readingtypeid:default_load_readingtypeid,
                    locationid:null,
                    sensortypeid:null
                },
                'trend':{
                    alias:'',
                    readingtypeid:default_readingtypeid,
                    locationid:null,
                    sensortypeid:null
                }
            },
            cost:{
                enabled:false,
                currency:currencies[0].value,
                unitrate:null
            },
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            type:'digit2',
            order:0,
            class:sizes['small'].value
        };
        this.order=0;
        this.status='draft';
        this.type='digit2';
    }


    function Digit2Settings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.currencies = currencies;
        this.sizes = [sizes['small'],sizes['xsmall']];
        this.parameterLimit = 1;
    }

    function Digit3() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:default_load_readingtypeid,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{name:'Demand',description:'Shows demand aggregated over 15 min fixed window'},
            type:'digit3',
            order:0,
            class:sizes['small'].value
        };
        this.order=0;
        this.status='draft';
        this.type='digit3';
    }


    function Digit3Settings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.sizes = [sizes['small'],sizes['xsmall']];
        this.parameterLimit = 1;
    }


    function Health() {
        this.config = {
            meta:{
                name:'Sensor Health',
                description:'Shows node Health. A node is termed as Inactive only if it fails to communicate with the SmartSense server for last 6 Hrs.'
            },
            type:'health',
            order:0,
            class:sizes['small'].value
        };
        this.order=0;
        this.status='draft';
        this.type='health';
    }


    function HealthSettings() {
        this.sizes = [sizes['small'],sizes['xsmall']];
    }


    function Trend() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:"1001"
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            dateRuleToCompare:{
                freq:null,
                reference:null,
                start:3,
                end:1
            },
            meta:meta,
            tocompare:3,
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='trend';
    }

    function TrendSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = angular.copy(frequencies).splice(2,2);
        this.grains = [{
            label: "1 Day",
            value:1440
        }];
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }


    function Graph() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:"1001"
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            class:sizes['full'].value,
            is_computed:true,
            computed_parameters:[{
                formula:[{
                    type:'parameter',
                    parameter:{}
                }],
                parameters:{}
            }]
        };
        this.status='draft';
        this.type='graph';
    }

    function GraphSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 8;
        this.sizes = [sizes['full'],sizes['half']];
    }

    function Heatmap() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            class:sizes['full'].value,
            heatmap:{
                min:null,
                max:null
            }
        };
        this.status='draft';
        this.type='heatmap';

    }

    function HeatmapSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.grains = [{
            label: "15 min",
            value: 15
        }];
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }

    function Pie() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:meta,
            class:sizes['small'].value
        };
        this.status='draft';
        this.type='pie';

    }

    function PieSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.parameterLimit = 8;
        this.sizes = [sizes['small'],sizes['xsmall'],sizes['half']];
    }

    function LiveTable() {
        this.config = {
            parameters:[],
            sensors:[],
            is_all_sensors:false,
            meta:{
                name:'Live Data',
                description:'Shows most recently recorded values of the parameters for the respective locations.',
                refreshtime:1
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='livetable';

    }

    function LiveTableSettings() {
        this.parameterLimit = 10;
        this.sensorLimit = 100;
        this.sizes = [sizes['half'],sizes['full']];
    }

    function LiveTable2() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            meta:{
                name:'Live Data',
                description:'Shows most recently recorded values of the parameters for the respective locations.',
                refreshtime:1
            },
            value_aliases:[],
            class:sizes['half'].value
        };
        this.status='draft';
        this.type='livetable2';

    }

    function LiveTable2Settings() {
        this.parameterLimit = 8;
        this.sizes = [sizes['half'],sizes['full']];
    }

    function LiveTable3() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            meta:{
                name:'Live Data',
                description:'It has different styling from other data tables.Shows most recently recorded values of the parameters for the respective sensors/locations.',
                refreshtime:1
            },
            value_aliases:[],
            class:sizes['medium'].value
        };
        this.status='draft';
        this.type='livetable3';

    }

    function LiveTable3Settings() {
        this.parameterLimit = 8;
        this.sizes = [sizes['medium'],sizes['half'],sizes['full']];
    }

    function Overview() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:default_readingtypeid,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            grain:1,
            meta:{
                name:'Overview',
                description:'Overview of location with option to select multi parameters.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='overview';
    }

    function OverviewSettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.sensortypeids = sensortypeids;
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }

    function SLD() {
        this.config = {
            parameters:[{
                readingtypeid:default_readingtypeid,
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{
                name:'SLD',
                description:'Shows SLD of the sensors as defined in Pre-Installation sheet. User may configure the Asset info in “settings”.'
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='sld';
    }

    function SLDSettings() {
        this.frequencies = frequencies;
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }

    function Insight() {
        this.config = {
            meta:{
                name:'Insight',
                description:'Shows insight of Assets.'
            },
            assets:{
                type:'motor',
                total:null,
                critical:null,
                potential:null
            },
            class:sizes['small'].value
        };
        this.status='draft';
        this.type='insight';
    }

    function InsightSettings() {
        this.assetTypes = assetTypes;
        this.sizes = [sizes['small'],sizes['xsmall']];
    }

    function Onoff() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{
                name:'On/Off Status',
                description:'Shows On/Off status on parameter value or based on the condition.',
                refreshtime:5
            },
            class:sizes['full'].value,
            is_computed:true,
            computed_parameters:[{
                formula:[{
                    type:'parameter',
                    parameter:{}
                }],
                parameters:{}
            }],
            grain:15
        };
        this.status='draft';
        this.type='onoff';
    }

    function OnoffSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 8;
        this.sizes = [sizes['full'],sizes['half']];
    }

    function OnoffDigit() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{
                name:'On/Off Status',
                description:'Shows Live On/Off status with running time.',
                refreshtime:5
            },
            class:sizes['small'].value,
            is_computed:true,
            computed_parameters:[{
                formula:[{
                    type:'parameter',
                    parameter:{}
                }],
                parameters:{}
            }],
            grain:15
        };
        this.status='draft';
        this.type='onoffdigit';
    }

    function OnoffDigitSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 1;
        this.sizes = [sizes['small'],sizes['xsmall']];
    }

    function OEE() {
        this.config = {
            parameters:[{
                locationid:null
            }],
            dateRule:{
                freq:'WEEKLY',
                reference:null,
                start:0,
                end:0
            },
            grain:1440,
            meta:{
                name:'Overall Equipment Effectiveness',
                description:'Shows Overall Equipment Effectiveness with Metrics and Time Distribution.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='oee';
    }

    function OEESettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }

    function Cycle() {
        this.config = {
            parameters:[{
                locationid:null,
                readingtypeid:null,
                sensorid:null
            }],
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            time:{
                start:'00:00',
                end:'00:00'
            },
            grain:1,
            meta:{
                name:'Cycle Distribution',
                description:'Cycle Distribution.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='cycle';
    }

    function CycleSettings() {
        this.frequencies = frequencies;
        this.sensortypeids = sensortypeids;
        this.grains = grains;
        this.parameterLimit = 1;
        this.sizes = [sizes['full']];
    }

    function Skyview() {
        this.config = {
            parameters:[],
            location:[],
            grain:15,
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            summaryName: '',
            meta:{
                name:'Skyview',
                description:'Skyview.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='skyview';
    }

    function SkyviewSettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 9;
        this.sizes = [sizes['full']];
    }

    function Gifimage() {
        this.config = {
            parameters:[{
                alias:'',
                readingtypeid:null,
                locationid:null,
                sensortypeid:null
            }],
            grain:15,
            order:0,
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{
                name:'Gif Image',
                description:'Gif Image.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='gifimage';
        this.order=0;
    }

    function GifimageSettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 8;
        this.sizes = [sizes['full']];
    }

    function TreeBuilder() {
        this.config = {
            tree: {},
            grain:15,
            order:0,
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta:{
                name:'Tree Builder',
                description:'Tree Builder.',
                refreshtime:5
            },
            class:sizes['full'].value
        };
        this.status='draft';
        this.type='treebuilder';
        this.order=0;
    }

    function TreeBuilderSettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 8;
        this.sizes = [sizes['full']];
    }

    function Dial() {
        this.config = {
            dateRule:{
                freq:'DAILY',
                reference:null,
                start:0,
                end:0
            },
            meta: {
                name:'Dial',
                description:'Dial Graph shows value of single location.',
                refreshtime:5
            },
            type:'dial',
            order:0,
            lower: '',
            upper: '',
            grain: 15,
            dial_type: 'solidgauge',
            solid_thresholds:[{
                label: 'Threshold',
                value: ''
            }],
            speedometer_thresholds:[{
                from: '',
                to: '',
                color: '',
            }],
            is_aggregated : false,
            class:sizes['small'].value,
            computed_parameters:[{
                formula:[{
                    type:'parameter',
                    parameter:{}
                }],
                parameters:{}
            }]
        };
        this.status='draft';
        this.type='dial';
        this.order=0;
    }

    function DialSettings() {
        this.frequencies = frequencies;
        this.grains = grains;
        this.parameterLimit = 8;
        this.thresholdLimit = 10;
        this.dialTypes = dialTypes;
        this.sizes = [sizes['small'],sizes['xsmall']];
    }

    function ImageUpload() { 
        this.config = { 
            dateRule:{ 
                freq:'DAILY', 
                reference:null, 
                start:0, 
                end:0 
            }, 
            computed_parameters:[{ 
                formula:[{ 
                    type:'parameter', 
                    parameter:{} 
                }], 
                parameters:{},
                threshold: '',
                threshold_color: '',
                style: { 
                    fontsize:'',
                    bordercolor: '',
                    bgcolor:'',
                    fontcolor:'',
                    fontweight: ''
                }, 
                position: { 
                    X:'', 
                    Y:'' 
                }
            }], 
            parameters:[{ 
                alias:'', 
                readingtypeid:null, 
                locationid:null, 
                sensortypeid:null,
                threshold: '',
                threshold_color: '',
                style: { 
                    fontsize:'', 
                    bordercolor: '', 
                    bgcolor:'', 
                    fontcolor:'',
                    fontweight: ''
                }, 
                position: { 
                    X:'', 
                    Y:'' 
                }
            }], 
            meta: { 
                name:'Image Upload', 
                description:'Shows Image with live parameters on it.', 
                refreshtime:5 
            }, 
            url: null,
            is_aggregated: false, 
            is_computed:false, 
            type:'imageupload', 
            order:0, 
            grain: 15, 
            class:sizes['full'].value 
        }; 
        this.status='draft'; 
        this.type='imageupload'; 
        this.order=0; 
 
    } 
 
    function ImageUploadSettings() { 
        this.sensortypeids = sensortypeids; 
        this.frequencies = frequencies; 
        this.grains = grains; 
        this.parameterLimit = 8; 
        this.sizes = [sizes['full']]; 
        this.fontweights = fontweights;
    }
    
    function HTML() {
        this.config = {
            meta: {
                name: 'HTML',
                description: '',
                refreshtime: 1
            },
            class: sizes['full'].value
        };
        this.status = 'draft';
        this.type = 'html';
    }


    function HTMLSettings() {
        this.sensortypeids = sensortypeids;
        this.frequencies = frequencies;
        this.sizes = [sizes['full'], sizes['small'], sizes['xsmall']];
        this.parameterLimit = 1;
    }


    function getObject(type) {
        if(type=='table') {
            return new Table();
        } else if(type=='digit') {
            return new Digit();
        } else if(type=='digit2') {
            return new Digit2();
        } else if(type=='digit3') {
            return new Digit3();
        } else if(type=='health') {
            return new Health();
        } else if(type=='trend') {
            return new Trend();
        } else if(type=='graph') {
            return new Graph();
        } else if(type=='heatmap') {
            return new Heatmap();
        } else if(type=='pie') {
            return new Pie();
        } else if(type=='livetable') {
            return new LiveTable();
        } else if(type=='livetable2') {
            return new LiveTable2();
        } else if(type=='livetable3') {
            return new LiveTable3();
        } else if(type=='overview') {
            return new Overview();
        } else if(type=='sld') {
            return new SLD();
        } else if(type=='insight') {
            return new Insight();
        } else if(type=='onoff') {
            return new Onoff();
        } else if(type=='onoffdigit') {
            return new OnoffDigit();
        } else if(type=='oee') {
            return new OEE();
        } else if(type=='cycle') {
            return new Cycle();
        } else if(type=='skyview') {
            return new Skyview();
        } else if(type=='gifimage') {
            return new Gifimage();
        } else if(type=='treebuilder') {
            return new TreeBuilder();
        } else if(type=='dial') {
            return new Dial();
        } else if(type=='imageupload') {
            return new ImageUpload();
        } else if (type == 'html') {
            return new HTML();
        }
    }

    function getSettings(type) {
        if(type=='table') {
            return new TableSettings();
        } else if(type=='digit') {
            return new DigitSettings();
        } else if(type=='digit2') {
            return new Digit2Settings();
        } else if(type=='digit3') {
            return new Digit3Settings();
        } else if(type=='health') {
            return new HealthSettings();
        } else if(type=='trend') {
            return new TrendSettings();
        } else if(type=='graph') {
            return new GraphSettings();
        } else if(type=='heatmap') {
            return new HeatmapSettings();
        } else if(type=='pie') {
            return new PieSettings();
        } else if(type=='livetable') {
            return new LiveTableSettings();
        } else if(type=='livetable2') {
            return new LiveTable2Settings();
        } else if(type=='livetable3') {
            return new LiveTable3Settings();
        } else if(type=='overview') {
            return new OverviewSettings();
        } else if(type=='sld') {
            return new SLDSettings();
        } else if(type=='insight') {
            return new InsightSettings();
        } else if(type=='onoff') {
            return new OnoffSettings();
        } else if(type=='onoffdigit') {
            return new OnoffDigitSettings();
        } else if(type=='oee') {
            return new OEESettings();
        } else if(type=='cycle') {
            return new CycleSettings();
        } else if(type=='skyview') {
            return new SkyviewSettings();
        } else if(type=='gifimage') {
            return new GifimageSettings();
        } else if(type=='treebuilder') {
            return new TreeBuilderSettings();
        } else if(type=='dial') {
            return new DialSettings();
        } else if(type=='imageupload') {
            return new ImageUploadSettings();
        } else if (type == 'html') {
            return new HTMLSettings();
        }

    }



}
