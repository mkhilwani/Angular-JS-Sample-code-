smartsenseApp.controller("widgetBuilderHTMLController", ["$scope", function($scope) {
    /*  Use from below toolbar options as and when needed

       'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'quote','bold', 'italics', 'underline', 
       'strikeThrough', 'ul', 'ol','undo', 'redo', 'clear','justifyLeft', 'justifyCenter', 'justifyRight',
       'justifyFull', 'indent', 'outdent','html','insertImage', 'imageSelect','wordcount', 'charcount' */


    // textAngular toolbar options 

    $scope.toolbarOptions = [
        ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'pre', 'quote'],
        ['bold', 'italics', 'underline', 'strikeThrough', 'ul', 'ol', 'clear'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull', 'indent', 'outdent'],
        ['html', 'insertImage', 'imageSelect'],
        ['wordcount', 'charcount']
    ];
}]);