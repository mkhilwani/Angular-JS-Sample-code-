smartsenseApp.controller("widgetBuilderController", widgetBuilderController);

widgetBuilderController.$inject = ['$scope', '$state', 'loading', 'apiService', 'widgetBuilderService', 'local', '$stateParams', 'widgetTypes', 'widgets'];

function widgetBuilderController($scope, $state, loading, apiService, widgetBuilderService, local, $stateParams, widgetTypes, widgets) {

    /* Set local data to use in other components */
    $scope.localData = local.data;
    $scope.locations = angular.copy($scope.localData.locations);
    $scope.widgets = widgets.data;
    $scope.settings = {};
    $scope.widget = {};

    // Complex Parameter
    $scope.operandtypes = widgetBuilderService.operandtypes;
    $scope.operators = widgetBuilderService.operators;
    $scope.chartTypes = widgetBuilderService.chartTypes;

    $scope.types = {}
    angular.forEach(widgetTypes.data.types, function(k, v) {
        $scope.types[k.value] = k;
    });

    $scope.searchByValue = function(arrayOfObjects, key, value) {
        var obj = {};
        if (arrayOfObjects instanceof Array) {
            for (var i = 0; i < arrayOfObjects.length; i++) {
                if (typeof arrayOfObjects[i][key] != "undefined" && arrayOfObjects[i][key] == value) {
                    obj = arrayOfObjects[i];
                }
            }
        }
        return obj;
    }

    $scope.ordinal_suffix_of = function(i) {
        return utils.ordinal_suffix_of(i);
    }

    $scope.getWidget = function(widgetid) {
        apiService.widget_get(widgetid).then(function(response) {
            $scope.widget = response.data;
        }, function(error) {});
    }

    $scope.$watch('widget.type', function(newVal, oldVal) {
        if (newVal != oldVal && newVal) {
            $scope.settings = angular.copy(widgetBuilderService.getSettings(newVal));
            if (!$scope.widget.widgetid) {
                $scope.widget = angular.copy(widgetBuilderService.getObject(newVal));
            }
        }
    });

    $scope.changeType = function(value) {
        if (!$scope.widget.widgetid) {
            $scope.widget.type = value;
        }
        setTimeout(function() {
            $(window).scrollTop($('#widgetAddContainer').offset().top - 70);
        }, 100);
    }

    $scope.addParameter = function() {
        $scope.widget.config.parameters.push({
            alias: '',
            readingtypeid: null,
            locationid: null,
            sensortypeid: null
        });
    }

    $scope.addComplexParameter = function() {
        $scope.widget.config.computed_parameters.push({
            formula: [{
                type: 'parameter',
                parameter: {}
            }]
        });
    }

    $scope.saveWidget = function(widget) {
        apiService.widget_save(widget).then(function(response) {
            $state.go('home.widgetBuilder', {}, { reload: true });
        }, function(error) {});
    }

    $scope.deleteWidget = function(widget) {
        bootbox.confirm("Are you sure you want to delete widget?", function(result) {
            if (result) {
                apiService.widget_delete(widget).then(function(response) {
                    $state.go('home.widgetBuilder', {}, { reload: true });
                }, function(error) {});
            }
        });
    }

    $scope.clone = function(widget) {
        var widget = angular.copy(widget);
        bootbox.confirm("Are you sure you want to clone this widget?", function(result) {
            if (result) {
                delete widget.widgetid;
                delete widget.order;
                delete widget.createdat;
                delete widget.modifiedat;
                if ('dateRange' in widget.config) {
                    delete widget.config.dateRange;
                };
                widget.config.meta.name = widget.config.meta.name + ' - copy';
                loading(true);
                apiService.widget_save(widget)
                    .success(function(data) {
                        loading(false);
                        $state.go('home.widgetBuilder', {}, { reload: true });
                    })
                    .error(function(err) {
                        loading(false);
                    });
            }
        });
    }

    $scope.initWidgetForm = function() {
        if ($stateParams.widgetid) {
            $scope.widget = {
                widgetid: $stateParams.widgetid
            }
            $scope.getWidget($stateParams.widgetid);
        } else {
            $scope.widget = {};
            $scope.settings = {};
        }
    }

    // Pie Chart Widget
    $scope.updateParameter = function(key) {
        angular.forEach($scope.widget.config.parameters, function(value, key) {
            if (key) {
                $scope.widget.config.parameters[key].readingtypeid = $scope.widget.config.parameters[0].readingtypeid;
            }
        });
    }

    // Copy frequency to compare_frequency
    $scope.copyFrequency = function() {
        $scope.widget.config.dateRuleToCompare.freq = $scope.widget.config.dateRule.freq;
    }

    // Pie Chart Widget Ends 
    $scope.changeOrder = function(widget1, widget2) {
        var reordered_widgets = [{
            'widgetid': widget1.widgetid,
            'order': widget2.order,
        }, {
            'widgetid': widget2.widgetid,
            'order': widget1.order,
        }];
        loading(true);
        apiService.widget_changeorder(reordered_widgets)
            .success(function(data) {
                $scope.widgets = data;
            })
            .catch(function(error) {})
            .finally(function() {
                loading(false);
            });
    }

    $scope.removeParameter = function(parameters, parameterToRemove) {
        var index = parameters.indexOf(parameterToRemove);
        if (index > -1) {
            parameters.splice(index, 1);
        }
    }

    $scope.locationLatLong = function() {
        apiService.get_location_with_geo().then(function(response) {
            for (var i = response.data.length - 1; i >= 0; --i) {
                if (response.data[i].latitude == null || response.data.latitude == '') {
                    response.data.splice(i, 1);
                }
            }
            $scope.locationlist = response.data;
        });
    }

    $scope.locationLatLong();


    $scope.onTypeChange = function(type, ngModel) {
        if (type == 'parameter') {
            ngModel.parameter = {};
            delete ngModel.value;
            delete ngModel.formula;
        } else if (type == 'value') {
            ngModel.value = null;
            delete ngModel.parameter;
            delete ngModel.formula;
        } else if (type == 'formula') {
            ngModel.formula = [{
                type: 'parameter',
                parameter: {}
            }];
            delete ngModel.value;
            delete ngModel.parameter;
        }
    }

    $scope.addOperator = function(ngModel) {
        ngModel.push({
            type: 'operator',
            value: '+'
        });
        ngModel.push({
            type: 'parameter',
            parameter: {}
        });
    }

    $scope.removeOperator = function(parameters, parameter) {
        var index = parameters.indexOf(parameter);
        if (index > 1) {
            parameters.splice(index - 1, 2);
        }
    }

    $scope.createEquation = function(formula) {
        var formulaText = '';
        if (formula instanceof Array) {
            angular.forEach(formula, function(value, index) {
                if (value.type == 'formula') {
                    formulaText += " ( " + $scope.createEquation(value.formula) + " ) ";
                } else {
                    var text = '';
                    if (value.type == 'operator') {
                        text = value.value;
                    } else if (value.type == 'parameter') {
                        if (value.parameter.locationid) {
                            text = $scope.locations[value.parameter.locationid].name;
                        }
                        if (value.parameter.readingtypeid) {
                            text += "_" + $scope.localData.readingtypes[value.parameter.readingtypeid].readingtypename;
                        }
                    } else if (value.type == 'value') {
                        text = value.value;
                    }
                    if (text) {
                        formulaText += text + ' ';
                    }
                }
            });
        }
        return formulaText;
    }

    var alphabets = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
    var alphabet_prefix = "df.";
    var alphabet_counter = 0;
    $scope.makeEquation = function(formula, index) {
        var formulaText = '';
        if (formula instanceof Array) {
            angular.forEach(formula, function(value) {
                if (value.type == 'formula') {
                    formulaText += " ( " + $scope.makeEquation(value.formula, index) + " ) ";
                } else {
                    var text = '';
                    if (value.type == 'operator') {
                        text = value.value;
                    } else if (value.type == 'parameter') {
                        var alphabet = alphabet_prefix + alphabets[alphabet_counter];
                        $scope.widget.config.computed_parameters[index].parameters[alphabet] = value.parameter;
                        text = alphabet;
                        alphabet_counter++;
                    } else if (value.type == 'value') {
                        text = value.value;
                    }
                    if (text) {
                        formulaText += text + ' ';
                    }
                }
            });
        }
        return formulaText;
    }

    $scope.$watch('widget.config.computed_parameters', function(newVal, oldVal) {
        if (newVal && newVal != oldVal) {
            angular.forEach(newVal, function(parameter, index) {
                alphabet_counter = 0;
                $scope.widget.config.computed_parameters[index].formulaText = $scope.createEquation(parameter.formula);
                $scope.widget.config.computed_parameters[index].parameters = {};
                $scope.widget.config.computed_parameters[index].formulaToParse = $scope.makeEquation(parameter.formula, index);
            });
        }
    }, true);

    // Value Alias
    $scope.addValueAlias = function() {
        if (!($scope.widget.config.value_aliases instanceof Array)) {
            $scope.widget.config.value_aliases = [];
        }
        $scope.widget.config.value_aliases.push({
            value: null,
            alias: ''
        });
    }

    $scope.removeValueAlias = function(alias) {
        var index = $scope.widget.config.value_aliases.indexOf(alias);
        if (index > -1) {
            $scope.widget.config.value_aliases.splice(index, 1);
        }
    }

}