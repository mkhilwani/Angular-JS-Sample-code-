smartsenseApp.controller("widgetBuilderDialController", widgetBuilderDialController);

widgetBuilderDialController.$inject = ['$scope', '$state', 'apiService', 'widgetBuilderService', 'local'];

function widgetBuilderDialController($scope, $state, apiService, widgetBuilderService, local) {

    $scope.addSolidThreshold = function() {
        $scope.widget.config.solid_thresholds = $scope.widget.config.solid_thresholds || [];
        $scope.widget.config.solid_thresholds.push({
            label: '',
            value: ''
        })
    };

    $scope.addSpeedometerThreshold = function() {
        $scope.widget.config.speedometer_thresholds = $scope.widget.config.speedometer_thresholds || [];
        $scope.widget.config.speedometer_thresholds.push({
            from: '',
            to: '',
            color: ''
        })
    };

    $scope.deleteThreshold = function(thresholds, thresholdToRemove) {
        var index = thresholds.indexOf(thresholdToRemove);
        if (index > -1) {
            thresholds.splice(index, 1);
        }
    }

}