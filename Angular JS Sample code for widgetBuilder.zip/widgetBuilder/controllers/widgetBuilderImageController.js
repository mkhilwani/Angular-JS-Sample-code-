smartsenseApp.controller("widgetBuilderImageController", widgetBuilderImageController);

widgetBuilderImageController.$inject = ['$scope', '$state', 'apiService', 'widgetBuilderService', 'local', 'loading'];

function widgetBuilderImageController($scope, $state, apiService, widgetBuilderService, local, loading) {

    $scope.addParameter = function() {
        $scope.widget.config.parameters.push({
            alias: '',
            readingtypeid: null,
            locationid: null,
            sensortypeid: null,
            style: {
                fontsize:'',
                bordercolor: '',
                bgcolor:'',
                fontcolor:'',
                fontweight: ''
            },
            position: {
                X:'',
                Y:''
            }
        });
    }

    $scope.addComplexParameter = function() {
        $scope.widget.config.computed_parameters.push({
            formula: [{
                type: 'parameter',
                parameter: {}
            }],
            style: {
                fontsize:'',
                bordercolor: '',
                bgcolor:'',
                fontcolor:'',
                fontweight: ''
            },
            position: {
                X:'',
                Y:''
            }
        });
    }

    $scope.removeParameter = function(parameters, parameterToRemove) {
        var index = parameters.indexOf(parameterToRemove);
        if (index > -1) {
            parameters.splice(index, 1);
        }
    }

    $scope.uploadFile = function(file){
        loading(true)
        $scope.widget.config.image_id = '';
        if (file) {
            var myFormData = new FormData();
            myFormData.append('file', file);
            apiService.media_handler(myFormData).then(function(response) {
                $scope.widget.config.url = response.data.url;
                $scope.url = $scope.widget.config.url;
                loading(false)
            })
        }
    };

    $scope.url = $scope.widget.config.url;

}