smartsenseApp.controller("widgetBuilderTableController", widgetBuilderTableController);

widgetBuilderTableController.$inject = ['$scope', '$state', 'apiService', 'widgetBuilderService', 'local'];

function widgetBuilderTableController($scope, $state, apiService, widgetBuilderService, local) {


    $scope.addParameter = function() {
        $scope.widget.config.cells.push({
            alias: '',
            is_computed: false,
            parameter: {
                readingtypeid: null,
                locationid: null,
                sensortypeid: null
            },
            computed_parameter: {
                formula: [{
                    type: 'parameter',
                    parameter: {}
                }],
                parameters: {}
            },
            col: null,
            row: null
        })
    };

    var getCellPosition = function(cell) {
        return cell.row.toSting() + cell.col.toString();
    }

    $scope.cellPositions = {};


    $scope.selectCell = function(cell, row, col) {
        var index = $scope.widget.config.cells.indexOf(cell);
        if (index > -1) {
            $scope.widget.config.cells[index].row = row;
            $scope.widget.config.cells[index].col = col;
        }
    }

    $scope.removeParameter = function(cell) {
        var index = $scope.widget.config.cells.indexOf(cell);
        if (index > -1) {
            $scope.widget.config.cells.splice(index, 1);
        }
    }

    $scope.addTableRow = function() {
        $scope.widget.config.rows = $scope.widget.config.rows || [];
        $scope.widget.config.rows.push({
            label: ''
        })
    };

    $scope.deleteTableRow = function(row) {
        var index = $scope.widget.config.rows.indexOf(row);
        if (index > -1) {
            $scope.widget.config.rows.splice(index, 1);
        }
    }

    $scope.addTableColumn = function() {
        $scope.widget.config.cols = $scope.widget.config.cols || [];
        $scope.widget.config.cols.push({
            label: ''
        })
    };

    $scope.deleteTableColumn = function(col) {
        var index = $scope.widget.config.cols.indexOf(col);
        console.log(index, col);
        if (index > -1) {
            $scope.widget.config.cols.splice(index, 1);
        }
    }

    $scope.mapCellPositions = function() {
        $scope.cellPositions = {};
        angular.forEach($scope.widget.config.cells, function(cell) {
            $scope.cellPositions[cell.row] = $scope.cellPositions[cell.row] || {};
            $scope.cellPositions[cell.row][cell.col] = cell;
        });
    }

    $scope.$watch('widget.config.cells', function(newVal, oldVal) {
        if (newVal) {
            $scope.mapCellPositions();
        }
    }, true);


}