smartsenseApp.controller("imageUploadModalController", ["$scope", "$state", "$uibModalInstance", "loading", "apiService", function($scope, $state, $uibModalInstance, loading, apiService) {
    $scope.isSubmitting = false;

    $scope.close = function() {
        $uibModalInstance.dismiss("cancel");
    };

    $scope.uploadFile = function(file) {
        // loading(true)
        $scope.isSubmitting = true;

        if (file) {
            var myFormData = new FormData();
            myFormData.append("file", file);
            apiService
                .media_handler(myFormData)
                .success(function(data) {
                    $scope.getImage(data);
                    // loading(false)
                })
                .error(function() {})
                .finally(function() {
                    $scope.isSubmitting = false;
                });
        } else {
            $scope.isSubmitting = false;
        }
    };

    $scope.getImage = function(data) {
        $scope.isSubmitting = true;

        var params = {
            media_handler_id: data.hash_key
        };
        apiService
            .media_handler_img(params)
            .success(function(data) {
                $scope.url = data;
                $uibModalInstance.close($scope.url);
            })
            .error(function() {})
            .finally(function() {
                $scope.isSubmitting = false;
            });
    };
}]);