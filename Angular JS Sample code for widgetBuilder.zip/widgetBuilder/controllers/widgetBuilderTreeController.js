smartsenseApp.controller("widgetBuilderTreeController", widgetBuilderTreeController);

widgetBuilderTreeController.$inject = ['$scope', '$state', 'apiService', 'widgetBuilderService', 'local'];

function widgetBuilderTreeController($scope, $state, apiService, widgetBuilderService, local) {

    $scope.sensors = $scope.localData.sensorlist;
    $scope.readingtypes = $scope.localData.readingtypeslist
    $scope.locations = $scope.localData.locations;
    $scope.tree = {};
    $scope.sensorlist = [];
    $scope.saveBtn = true;
    angular.forEach($scope.sensors, function(k, v) {
        $scope.sensorlist.push({
            name: k.name,
            sensorid: k.sensorid
        })
    })

    $scope.tagTransform = function(newTag) {
        var item = {
            name: newTag,
            sensorid: ''
        };
        return item;
    };

    $scope.disabled = undefined;

    $scope.treeConfig = {
        core: {
            multiple: false,
            animation: true,
            error: function(error) {
                $log.error('treeCtrl: error from js tree - ' + angular.toJson(error));
            },
            check_callback: true,
            worker: true
        },
        types: {
            default: {
                icon: 'fa fa-info-circle'
            }
        },
        version: 1,
        plugins: ['types', 'contextmenu', 'conditionalselect'],
        contextmenu: {
            items: function(node) {
                return {
                    "Rename": {
                        "separator_before": false,
                        "separator_after": false,
                        "label": "Edit",
                        "icon": "fa fa-pencil",
                        "action": function(obj) {
                            apiService.get_single_node(node.id).then(function(response) {
                                $scope.updateBtn = true;
                                $scope.saveBtn = false;
                                $scope.nodelist = {
                                    sensorname: [{
                                        name: response.data.name,
                                        sensorid: response.data.sensorid
                                    }],
                                    nodename: response.data.name,
                                    parent: response.data.parent,
                                    readingtypeid: response.data.readingtypeid,
                                    showalert: response.data.showalerts,
                                    id: response.data.id
                                };
                            })
                        }
                    },
                    "Remove": {
                        "separator_before": false,
                        "separator_after": false,
                        "label": "Remove",
                        "icon": "fa fa-trash",
                        "action": function(obj) {
                            var tree = $("#tree").jstree(true);
                            var id = tree._model.data[node.id].id;
                            apiService.delete_node(id).then(function(response) {
                                tree.delete_node(node);
                            })
                        }
                    }
                };
            }
        }
    };

    $scope.reCreateTree = function() {
        $scope.treeConfig.version++;
    }

    $scope.createTree = {
        treename: ''
    };

    $scope.createTree = function() {
        var params = {
            memberid: $scope.localData.memberId,
            name: $scope.createTree.treename
        }
        apiService.create_tree(params).then(function(response) {
            bootbox.alert("Tree has been Created.")
            $scope.getTreeList();
        }, function() {});
        $scope.createTree = {
            treename: '',
        };
    }

    $scope.getTreeList = function() {
        apiService.retrieve_tree().then(function(response) {
            $scope.treeList = response.data;
            if($scope.widget.config.tree.id != undefined) {
                $scope.getTreeNodes($scope.widget.config.tree.id)
            } else {
                $scope.widget.config.tree = $scope.treeList[0];
                $scope.getTreeNodes($scope.treeList[0].id);
            }
        }, function() {
        });
    }

    $scope.getTreeList();

    $scope.nodelist = {
        sensorname: [],
        nodename: '',
        parent: '',
        readingtypeid: '',
        showalert: ''
    };

    $scope.submitNode = function(treeid) {
        var params = {
            sensorid: $scope.nodelist.sensorname[0]['sensorid'],
            name: $scope.nodelist.sensorname[0]['name'],
            parent: $scope.nodelist.parent,
            readingtypeid: $scope.nodelist.readingtypeid,
            treeid: treeid,
            order: 3,
            showalerts: $scope.nodelist.showalert
        }
        apiService.create_node(params).then(function(response) {
            $scope.getTreeNodes(treeid);
            $scope.nodelist = {
                sensorname: [],
                nodename: '',
                parent: '',
                readingtypeid: '',
                showalert: ''
            };
        }, function() {});
    }

    $scope.getTreeNodes = function(treeid) {
        apiService.sensors().then(function(response) {
            $scope.sensorlist = response.data;
        })
        apiService.get_tree_nodes(treeid).then(function(response) {
            for (var i = 0; i < response.data.data.length; i++) {
                for (var x = 0; x < $scope.sensorlist.length; x++) {
                    if (response.data.data[i].sensorid == $scope.sensorlist[x].sensorid) {
                        $scope.sensorlist.splice(x, 1);
                    };
                };
            }
            $scope.originalData = response.data.data;
            $scope.parentData = []
            angular.forEach($scope.originalData, function(k, v) {
                $scope.parentData.push({
                    text: k.name,
                    id: k.id,
                })
            })
            for (var i = 0; i < $scope.originalData.length; i++) {
                $scope.originalData[i].text = $scope.originalData[i].name + ' : ' + $scope.originalData[i].readingtypeid.readingtypename;
                delete $scope.originalData[i].name;
                if ($scope.originalData[i].parent == null) {
                    $scope.originalData[i].parent = '#'
                }
                $scope.originalData[i].state = {
                    opened: true
                }
                $scope.originalData[i].li_attr = {
                    readingtypeid: $scope.originalData[i].readingtypeid
                }
            }
            $scope.treeData = [];
            angular.copy($scope.originalData, $scope.treeData);
            $scope.reCreateTree();
        }, function() {});
    }

    $scope.updateNode = function(treeid) {
        var params = {
            sensorid: $scope.nodelist.sensorname[0]['sensorid'],
            name: $scope.nodelist.sensorname[0]['name'],
            parent: $scope.nodelist.parent,
            readingtypeid: $scope.nodelist.readingtypeid,
            treeid: treeid,
            order: 3,
            showalerts: $scope.nodelist.showalert,
            id: $scope.nodelist.id
        }
        apiService.edit_node(params).then(function(response) {
            $scope.getTreeNodes(treeid)
            $scope.updateBtn = false;
            $scope.saveBtn = true;
            $scope.nodelist = {
                sensorname: [],
                nodename: '',
                parent: '',
                readingtypeid: '',
                showalert: ''
            };
        })
    }

    $scope.ignoreChanges = false;

    $scope.applyModelChanges = function() {
        return !$scope.ignoreChanges;
    };

}