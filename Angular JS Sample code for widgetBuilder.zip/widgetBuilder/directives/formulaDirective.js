smartsenseApp.directive('widgetFormula', ["RecursionHelper", function(RecursionHelper) {
    return {
        restrict: 'AE',
        scope: {
            formula: '=',
            types: '=',
            operators: '=',
            locations: '=',
            readingtypes: '=',
            sensortypeids: '=',
            onTypeChange: '&',
            addOperator: '&',
            removeOperator: '&'
        },
        templateUrl: 'components/widgetBuilder/templates/computed_parameters/formula.tpl.html',
        replace: true,
        compile: function(element) {
            // Use the compile function from the RecursionHelper,
            // And return the linking function(s) which it returns
            return RecursionHelper.compile(element);
        }
    };
}]);

smartsenseApp.directive('computedParameter', ["RecursionHelper", function(RecursionHelper) {
    return {
        restrict: 'AE',
        scope: {
            parameter: '=',
            types: '=',
            operators: '=',
            locations: '=',
            readingtypes: '=',
            sensortypeids: '=',
            onTypeChange: '&',
            isParent: '='
        },
        templateUrl: 'components/widgetBuilder/templates/table/formula.tpl.html',
        replace: true,
        compile: function(element) {
            // Use the compile function from the RecursionHelper,
            // And return the linking function(s) which it returns
            return RecursionHelper.compile(element, function(scope, element, attrs) {
                var alphabets = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
                var alphabet_prefix = "df.";
                var alphabet_counter = 0;

                scope.addOperator = function(ngModel) {
                    ngModel.push({
                        type: 'operator',
                        value: '+'
                    });
                    ngModel.push({
                        type: 'parameter',
                        parameter: {}
                    });
                };

                scope.removeOperator = function(parameters, parameter) {
                    var index = parameters.indexOf(parameter);
                    if (index > 1) {
                        parameters.splice(index - 1, 2);
                    }
                }

                scope.makeEquation = function(formula) {
                    var formulaText = '';
                    if (formula instanceof Array) {
                        angular.forEach(formula, function(value) {
                            if (value.type == 'formula') {
                                formulaText += " ( " + scope.makeEquation(value.formula) + " ) ";
                            } else {
                                var text = '';
                                if (value.type == 'operator') {
                                    text = value.value;
                                } else if (value.type == 'parameter') {
                                    var alphabet = alphabet_prefix + alphabets[alphabet_counter];
                                    scope.parameter.parameters[alphabet] = value.parameter;
                                    text = alphabet;
                                    alphabet_counter++;
                                } else if (value.type == 'value') {
                                    text = value.value;
                                }
                                if (text) {
                                    formulaText += text + ' ';
                                }
                            }
                        });
                    }
                    return formulaText;
                };
                scope.createEquation = function(formula) {
                    var formulaText = '';
                    if (formula instanceof Array) {
                        angular.forEach(formula, function(value, index) {
                            if (value.type == 'formula') {
                                formulaText += " ( " + scope.createEquation(value.formula) + " ) ";
                            } else {
                                var text = '';
                                if (value.type == 'operator') {
                                    text = value.value;
                                } else if (value.type == 'parameter') {
                                    if (value.parameter.locationid) {
                                        text = scope.locations[value.parameter.locationid].name;
                                    }
                                    if (value.parameter.readingtypeid) {
                                        text += "_" + scope.readingtypes[value.parameter.readingtypeid].readingtypename;
                                    }
                                } else if (value.type == 'value') {
                                    text = value.value;
                                }
                                if (text) {
                                    formulaText += text + ' ';
                                }
                            }
                        });
                    }
                    return formulaText;
                }
                scope.$watch('parameter', function(newVal, oldVal) {
                    if (scope.isParent && newVal && newVal != oldVal) {
                        alphabet_counter = 0;
                        scope.parameter.formulaText = scope.createEquation(newVal.formula);
                        scope.parameter.parameters = {};
                        scope.parameter.formulaToParse = scope.makeEquation(newVal.formula, alphabet_counter);
                    }
                }, true);
            });
        }
    };
}]);